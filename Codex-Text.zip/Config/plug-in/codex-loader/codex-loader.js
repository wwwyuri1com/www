(() => {
    const catalogRoot =
        document.getElementById("codex-filter-catalog");

    const tagRoot =
        document.getElementById("codex-filter-tag");

    const resultRoot =
        document.querySelector(
            ".codex-boss .codex-loader.codex-banshee .codex-results"
        );

    const catalogTemplate =
        document.getElementById(
            "codex-catalog-template"
        );

    const postTemplate =
        document.getElementById(
            "codex-post-template"
        );

    if (
        !catalogRoot &&
        !tagRoot &&
        !resultRoot
    ) {
        return;
    }

    loadSelectors();


    async function loadSelectors() {
        try {
            const requests = [];


            if (catalogRoot) {
                requests.push(
                    fetch("Codex-W/W-Catalog.json")
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(
                                    `W-Catalog request failed (${response.status})`
                                );
                            }

                            return response.json();
                        })
                        .then(data =>
                            buildCatalogSelector(data)
                        )
                );
            }


            if (tagRoot) {
                requests.push(
                    fetch("Codex-W/W-Tag.json")
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(
                                    `W-Tag request failed (${response.status})`
                                );
                            }

                            return response.json();
                        })
                        .then(data =>
                            buildTagSelector(data)
                        )
                );
            }


            if (resultRoot) {
                requests.push(
                    loadCodexResult()
                        .then(() => {
                            renderStatusIcons();
                        })
                );
            }


            await Promise.all(requests);

        } catch (error) {
            console.error(
                "Codex-W:",
                error
            );
        }
    }


    async function loadCodexResult() {
        const params =
            new URLSearchParams(
                window.location.search
            );

        const catalogQuery =
            params.get("catalog");

        const tagQuery =
            params.get("tag");


        try {
            if (
                catalogQuery === "Favorite" &&
                tagQuery === null
            ) {
                await renderFavoriteResult();
                return;
            }

            const requests = [];


            if (catalogQuery !== null) {
                requests.push(
                    fetch("Codex-W/W-Catalog.json")
                        .then(async response => {
                            if (!response.ok) {
                                throw new Error(
                                    `W-Catalog request failed (${response.status})`
                                );
                            }

                            return {
                                type: "catalog",
                                data:
                                    await response.json()
                            };
                        })
                );
            }


            if (tagQuery !== null) {
                requests.push(
                    fetch("Codex-W/W-Tag.json")
                        .then(async response => {
                            if (!response.ok) {
                                throw new Error(
                                    `W-Tag request failed (${response.status})`
                                );
                            }

                            return {
                                type: "tag",
                                data:
                                    await response.json()
                            };
                        })
                );
            }


            if (
                catalogQuery === null &&
                tagQuery === null
            ) {
                requests.push(
                    fetch("Codex-W/W-Catalog.json")
                        .then(async response => {
                            if (!response.ok) {
                                throw new Error(
                                    `W-Catalog request failed (${response.status})`
                                );
                            }

                            return {
                                type: "catalog-all",
                                data:
                                    await response.json()
                            };
                        })
                );
            }


            const results =
                await Promise.all(requests);


            const result =
                results[0];


            if (!result) {
                renderMessage(
                    "Unable to load Codex."
                );

                return;
            }


            if (result.type === "tag") {
                await renderTagResult(
                    result.data,
                    tagQuery
                );

            } else {
                await renderCatalogResult(
                    result.data,
                    catalogQuery
                );
            }

        } catch (error) {
            console.error(
                "Codex result:",
                error
            );

            renderMessage(
                "Unable to load Codex."
            );
        }
    }


    async function renderFavoriteBox() {
        const favoriteIds =
            getFavoritePostIds();

        if (favoriteIds.length === 0) {
            return;
        }

        const posts =
            await loadPostData(favoriteIds);

        const visiblePosts = [];

        for (const postId of favoriteIds) {
            const post =
                createPostElement(
                    postId,
                    posts.get(postId),
                    0
                );

            if (post) {
                visiblePosts.push(post);
            }
        }

        if (visiblePosts.length === 0) {
            return;
        }

        const box =
            document.createElement("div");

        box.className =
            "codex-favo-box";

        const title =
            document.createElement("div");

        title.className =
            "codex-favo-title";

        title.textContent =
            "♥︎ FAVO";

        box.appendChild(title);

        const list =
            document.createElement("div");

        list.className =
            "codex-favo-list";

        for (const post of visiblePosts) {
            list.appendChild(post);
        }

        box.appendChild(list);

        resultRoot.appendChild(box);
    }


    async function renderFavoriteResult() {
        clearResult();

        appendResultHeader("♥︎ FAVORITE");

        const favoriteIds = getFavoritePostIds();

        if (favoriteIds.length === 0) {
            renderMessage("No favorite posts.");
            return;
        }

        const posts = await loadPostData(favoriteIds);

        const postList =
            document.createElement("div");

        postList.className =
            "codex-post-list";

        for (const postId of favoriteIds) {
            const post =
                createPostElement(
                    postId,
                    posts.get(postId),
                    0
                );

            if (post) {
                postList.appendChild(post);
            }
        }

        if (postList.children.length === 0) {
            renderMessage("No favorite posts.");
            return;
        }

        resultRoot.appendChild(postList);
    }

    function getFavoritePostIds() {
        const prefix =
            "yuri1.reader.favorite.";

        const ids = [];

        for (let index = 0; index < localStorage.length; index++) {
            const key = localStorage.key(index);

            if (!key || !key.startsWith(prefix)) {
                continue;
            }

            if (localStorage.getItem(key) !== "true") {
                continue;
            }

            const postId =
                key.slice(prefix.length);

            if (postId && !ids.includes(postId)) {
                ids.push(postId);
            }
        }

        return ids;
    }

    async function renderCatalogResult(
        data,
        catalogQuery
    ) {
        clearResult();


        /*
         * Root Codex page:
         * show the user's favorites as a small
         * "user" style card above the normal Codex navigation.
         * This does not modify the Select UI.
         */
        if (
            catalogQuery === null &&
            new URLSearchParams(window.location.search).get("tag") === null
        ) {
            await renderFavoriteBox();
        }


        const title = "𖤐 Codex";

        appendResultHeader(title);

        const hidePosts =
            new Set(
                Array.isArray(
                    data?.selector?.hide_posts
                )
                    ? data.selector.hide_posts
                    : []
            );

        const separatorBefore =
            new Set(
                Array.isArray(
                    data?.selector?.separator_before
                )
                    ? data.selector.separator_before
                    : []
            );


        let node =
            data?.catalogs || {};


        if (
            catalogQuery &&
            catalogQuery !== "All"
        ) {
            node =
                findCatalogNode(
                    node,
                    catalogQuery.split("/")
                );
        }


        if (!node) {
            renderMessage(
                "Catalog not found."
            );

            return;
        }


        if (
            catalogQuery === null ||
            catalogQuery === "All"
        ) {
            await renderCatalogNodes(
                node,
                "",
                true,
                hidePosts,
                separatorBefore
            );

        } else {
            /*
             * Direct catalog view is the explicit exception:
             * hidden Catalogs show their Posts here.
             */
            await renderCatalogNode(
                getLastPathPart(
                    catalogQuery
                ),
                node,
                catalogQuery,
                0,
                true,
                false
            );
        }
    }


    async function renderCatalogNodes(
        nodes,
        parentPath = "",
        showAllRoots = false,
        hidePosts = new Set(),
        separatorBefore = new Set()
    ) {
        if (showAllRoots) {

            for (
                const [name, node]
                of Object.entries(nodes)
            ) {
                await renderCatalogNode(
                    name,
                    node,
                    name,
                    0,
                    true,
                    hidePosts.has(name),
                    separatorBefore.has(name)
                );
            }

            return;
        }


        if (
            nodes &&
            typeof nodes === "object" &&
            !Array.isArray(nodes)
        ) {
            const name =
                getLastPathPart(
                    parentPath
                );

            await renderCatalogNode(
                name,
                nodes,
                parentPath,
                0,
                true
            );
        }
    }


    async function renderCatalogNode(
        name,
        node,
        path,
        depth,
        showTitle = true,
        hideDirectPosts = false,
        separatorBefore = false
    ) {
        if (separatorBefore) {
            const divider =
                document.createElement("hr");

            divider.className =
                "codex-catalog-divider";

            resultRoot.appendChild(divider);
        }

        /*
         * Keep Codex rendering consistent with the
         * Catalog selector: empty Catalog branches
         * are hidden instead of being rendered.
         */
        if (!catalogHasPosts(node)) {
            return;
        }

        const catalog =
            cloneTemplate(
                catalogTemplate
            );


        if (!catalog) {
            return;
        }


        const catalogTitle =
            catalog.querySelector(
                '[data-codex="catalog-title"]'
            );

        const catalogLink =
            catalog.querySelector(
                '[data-codex="catalog-link"]'
            );


        if (
            showTitle &&
            catalogTitle &&
            catalogLink
        ) {
            catalogLink.href =
                `Codex.html?catalog=${encodeURIComponent(
                    path
                )}`;

            catalogLink.textContent =
                `${indent(depth)}✧ ${name}`;

        } else if (catalogTitle) {
            catalogTitle.remove();
        }


        const postList =
            catalog.querySelector(
                '[data-codex="post-list"]'
            );


        const posts =
            Array.isArray(node?.posts)
                ? node.posts
                : [];


        if (
            postList &&
            posts.length > 0 &&
            !hideDirectPosts
        ) {
            const postData =
                await loadPostData(posts);


            for (
                const postId
                of posts
            ) {
                const post =
                    createPostElement(
                        postId,
                        postData.get(postId),
                        depth +
                            (showTitle ? 1 : 0)
                    );


                if (post) {
                    postList.appendChild(
                        post
                    );
                }
            }
        }


        /*
         * Catalog is always rendered,
         * even when it has no Posts.
         */
        resultRoot.appendChild(
            catalog
        );


        /*
         * Children are independent
         * from Posts.
         */
        if (
            node?.children &&
            typeof node.children === "object"
        ) {
            for (
                const [
                    childName,
                    childNode
                ]
                of Object.entries(
                    node.children
                )
            ) {
                await renderCatalogNode(
                    childName,
                    childNode,
                    path
                        ? `${path}/${childName}`
                        : childName,
                    depth + 1,
                    true,
                    hideDirectPosts
                );
            }
        }
    }


    async function renderTagResult(
        data,
        tag
    ) {
        clearResult();


        appendResultHeader(
            `✦ #${tag}`
        );


        const tagData =
            data?.tags?.[tag];


        if (
            !tagData ||
            !Array.isArray(
                tagData.posts
            )
        ) {
            renderMessage(
                "Tag not found."
            );

            return;
        }


        const posts =
            await loadPostData(
                tagData.posts
            );


        const postList =
            document.createElement(
                "div"
            );

        postList.className =
            "codex-post-list";


        for (
            const postId
            of tagData.posts
        ) {
            const post =
                createPostElement(
                    postId,
                    posts.get(postId),
                    0
                );


            if (post) {
                postList.appendChild(
                    post
                );
            }
        }


        resultRoot.appendChild(
            postList
        );
    }


    async function loadPostData(
        postIds
    ) {
        const dataMap =
            new Map();


        await Promise.all(
            postIds.map(
                async postId => {
                    try {
                        const response =
                            await fetch(
                                `Codex-Text/${encodeURIComponent(
                                    postId
                                )}.json`
                            );


                        if (!response.ok) {
                            return;
                        }


                        const data =
                            await response.json();


                        if (
                            data &&
                            data.id === postId
                        ) {
                            dataMap.set(
                                postId,
                                data
                            );
                        }

                    } catch {
                        /*
                         * Keep the Post ID.
                         * Renderer will fall back
                         * to a readable ID.
                         */
                    }
                }
            )
        );


        return dataMap;
    }


    function renderStatusIcons() {
        if (
            window.lucide &&
            typeof window.lucide.createIcons ===
                "function"
        ) {
            window.lucide.createIcons();
        }
    }


    function createPostElement(
        postId,
        data,
        depth
    ) {
        const post =
            cloneTemplate(
                postTemplate
            );


        if (!post) {
            return null;
        }


        post.dataset.postId =
            postId;


        const imageBlock =
            post.querySelector(
                '[data-codex="post-image"]'
            );


        const image =
            post.querySelector(
                '[data-codex="post-image-link"]'
            );


        const titleLink =
            post.querySelector(
                '[data-codex="post-link"]'
            );


        const date =
            post.querySelector(
                '[data-codex="post-date"]'
            );


        const displayTitle =
            data?.title ||
            humanizeId(postId);


        if (imageBlock && image) {
            image.className =
                "post codex";

            image.alt =
                displayTitle;

            let coverNumber = window.YURI1Cover
                ? window.YURI1Cover.get(postId)
                : 1;

            const applyCover = number => {
                coverNumber = number;
                image.src = window.YURI1Cover
                    ? window.YURI1Cover.src(postId, number)
                    : `Codex-Img/${encodeURIComponent(postId)}%20(${number}).jpg`;
            };

            image.loading =
                "lazy";

            image.decoding =
                "async";

            image.addEventListener(
                "error",
                () => {
                    if (coverNumber !== 1) {
                        coverNumber = 1;
                        if (window.YURI1Cover) {
                            window.YURI1Cover.set(postId, 1);
                        }
                        applyCover(1);
                        return;
                    }

                    imageBlock.remove();
                }
            );

            applyCover(coverNumber);
        }


        const titleContainer =
            post.querySelector(
                '[data-codex="post-title"]'
            );

        if (titleLink) {
            titleLink.href =
                `Post.html?id=${encodeURIComponent(
                    postId
                )}`;

            titleLink.textContent =
                displayTitle;
        }

        const doneKey =
            `yuri1.reader.done.${postId}`;

        const favoriteKey =
            `yuri1.reader.favorite.${postId}`;

        let isReadDone =
            localStorage.getItem(doneKey) ===
            "true";

        let isFavorite =
            localStorage.getItem(favoriteKey) ===
            "true";

        if (
            titleContainer &&
            isReadDone
        ) {
            titleContainer.classList.add(
                "is-read-done"
            );
        }

        /*
         * Fixed right-side metadata: <date> <favorite> <read-done>.
         * Both status buttons are always visible so every Codex row
         * keeps the same alignment. Clicking an icon toggles its state.
         */
        const meta =
            document.createElement("div");

        meta.className =
            "codex-post-meta";

        post.appendChild(meta);

        if (date) {
            meta.appendChild(date);
        }

        const createStatusButton = (
            type,
            iconName,
            key,
            active,
            activeLabel,
            inactiveLabel
        ) => {
            const button =
                document.createElement("button");

            button.type =
                "button";

            button.className =
                `codex-post-status-slot ${type}`;

            button.setAttribute(
                "aria-pressed",
                String(active)
            );

            button.setAttribute(
                "aria-label",
                active ? activeLabel : inactiveLabel
            );

            button.setAttribute(
                "title",
                active ? activeLabel : inactiveLabel
            );

            const icon =
                document.createElement("i");

            icon.setAttribute(
                "data-lucide",
                iconName
            );

            icon.className =
                "codex-post-status-icon";

            button.appendChild(
                icon
            );

            button.classList.toggle(
                "is-active",
                active
            );

            button.addEventListener(
                "click",
                event => {
                    event.preventDefault();
                    event.stopPropagation();

                    const current =
                        localStorage.getItem(key) ===
                        "true";

                    if (current) {
                        localStorage.removeItem(key);
                    } else {
                        localStorage.setItem(
                            key,
                            "true"
                        );
                    }

                    const next =
                        !current;

                    button.classList.toggle(
                        "is-active",
                        next
                    );

                    button.setAttribute(
                        "aria-pressed",
                        String(next)
                    );

                    const label =
                        next
                            ? activeLabel
                            : inactiveLabel;

                    button.setAttribute(
                        "aria-label",
                        label
                    );

                    button.setAttribute(
                        "title",
                        label
                    );

                    if (
                        type ===
                        "read-done" &&
                        titleContainer
                    ) {
                        titleContainer.classList.toggle(
                            "is-read-done",
                            next
                        );
                    }
                }
            );

            meta.appendChild(
                button
            );
        };

        createStatusButton(
            "favorite",
            "book-heart",
            favoriteKey,
            isFavorite,
            "Remove from favorites",
            "Add to favorites"
        );

        createStatusButton(
            "read-done",
            "book-check",
            doneKey,
            isReadDone,
            "Mark as unread",
            "Mark as read"
        );

        if (date) {
            const dateText =
                data?.date || "";


            const span =
                date.querySelector(
                    "span"
                );


            if (span) {
                span.textContent =
                    dateText;

            } else {
                date.textContent =
                    dateText;
            }
        }


        if (depth > 0) {
            post.style.marginLeft =
                `${depth}em`;
        }


        return post;
    }


    function cloneTemplate(
        template
    ) {
        if (!template) {
            return null;
        }


        const fragment =
            template.content.cloneNode(
                true
            );


        return fragment.firstElementChild;
    }


    function clearResult() {
        if (!resultRoot) {
            return;
        }


        resultRoot.replaceChildren();
    }


    function appendResultHeader(
        text
    ) {
        if (!resultRoot) {
            return;
        }


        /*
         * Home
         */
        const homeHeader =
            document.createElement(
                "div"
            );

        homeHeader.className =
            "codex-header";


        const homeLink =
            document.createElement(
                "a"
            );

        homeLink.href =
            "index.html";

        homeLink.textContent =
            "⛶ Home";


        homeHeader.appendChild(
            homeLink
        );

        resultRoot.appendChild(
            homeHeader
        );


        /*
         * Codex
         */
        const codexHeader =
            document.createElement(
                "div"
            );

        codexHeader.className =
            "codex-header";


        const codexLink =
            document.createElement(
                "a"
            );

        codexLink.href =
            "Codex.html?catalog=All";

        codexLink.textContent =
            "𖤐 Codex";


        codexHeader.appendChild(
            codexLink
        );

        resultRoot.appendChild(
            codexHeader
        );


        /*
         * Current result title
         *
         * Only add it when it is not
         * already the Codex root.
         */
        if (
            text &&
            text !== "𖤐 Codex"
        ) {
            const currentHeader =
                document.createElement(
                    "div"
                );

            currentHeader.className =
                "codex-header";

            currentHeader.textContent =
                text;

            resultRoot.appendChild(
                currentHeader
            );
        }
    }


    function renderMessage(
        text
    ) {
        if (!resultRoot) {
            return;
        }


        const message =
            document.createElement(
                "div"
            );

        message.className =
            "codex-message";

        message.textContent =
            text;


        resultRoot.appendChild(
            message
        );
    }


    function findCatalogNode(
        catalogs,
        parts
    ) {
        let current =
            catalogs;


        for (
            let i = 0;
            i < parts.length;
            i++
        ) {
            const part =
                parts[i];


            if (
                !current ||
                typeof current !== "object"
            ) {
                return null;
            }


            const node =
                current[part];


            if (!node) {
                return null;
            }


            if (
                i === parts.length - 1
            ) {
                return node;
            }


            current =
                node.children;
        }


        return null;
    }


    function getLastPathPart(
        path
    ) {
        const parts =
            String(path || "")
                .split("/");


        return (
            parts[parts.length - 1] ||
            "Codex"
        );
    }


    async function buildCatalogSelector(
        data
    ) {
        const select =
            catalogRoot.querySelector(
                "select"
            );


        if (!select) {
            return;
        }


        const placeholder =
            select.querySelector(
                'option[value=""]'
            );


        select.textContent = "";


        if (placeholder) {
            select.appendChild(
                placeholder
            );

        } else {
            const option =
                createOption(
                    "",
                    "⛛ Select Catalog",
                    "placeholder"
                );


            option.disabled =
                true;

            option.selected =
                true;

            option.hidden =
                true;


            select.appendChild(
                option
            );
        }


        /*
         * Favorite
         */
        select.appendChild(
            createOption(
                "Favorite",
                "♥︎ FAVORITE",
                "favorite",
                "Favorite"
            )
        );

        /*
         * Codex root.
         */
        select.appendChild(
            createOption(
                "All",
                "𖤐 Codex",
                "catalog",
                "All"
            )
        );


        const printPosts =
            new Set(
                Array.isArray(
                    data?.selector?.print_posts
                )
                    ? data.selector.print_posts
                    : []
            );

        /*
         * Catalogs listed here keep their Catalog entry,
         * but never print their Posts in the SELECT.
         * This applies to every Post ID, with or without "_".
         */
        const hidePosts =
            new Set(
                Array.isArray(
                    data?.selector?.hide_posts
                )
                    ? data.selector.hide_posts
                    : []
            );

        const separatorBefore =
            new Set(
                Array.isArray(
                    data?.selector?.separator_before
                )
                    ? data.selector.separator_before
                    : []
            );


        const catalogs =
            data?.catalogs || {};


        /*
         * Only show Catalog entries that contain
         * at least one Post somewhere in their tree.
         */
        const visibleCatalogs =
            Object.fromEntries(
                Object.entries(catalogs)
                    .filter(([, node]) =>
                        catalogHasPosts(node)
                    )
            );


        if (Object.keys(visibleCatalogs).length === 0) {
            catalogRoot.hidden = true;
            return;
        }


        catalogRoot.hidden = false;


        await appendCatalogs(
            select,
            visibleCatalogs,
            "",
            0,
            printPosts,
            hidePosts,
            separatorBefore
        );


        /*
         * Home stays at the bottom so it is not confused
         * with the content/navigation entries above.
         */
        select.appendChild(
            createOption(
                "Home",
                "⛶ Home",
                "home",
                "Home"
            )
        );


        select.addEventListener(
            "change",
            () => {
                const option =
                    select.options[
                        select.selectedIndex
                    ];


                if (!option) {
                    return;
                }


                if (
                    option.dataset.type ===
                    "favorite"
                ) {
                    window.location.href =
                        "Codex.html?catalog=Favorite";

                    return;
                }

                if (
                    option.dataset.type ===
                    "home"
                ) {
                    window.location.href =
                        "index.html";

                    return;
                }


                if (
                    option.dataset.type ===
                    "post"
                ) {
                    window.location.href =
                        `Post.html?id=${encodeURIComponent(
                            option.value
                        )}`;

                    return;
                }


                if (
                    option.value ===
                    "All"
                ) {
                    window.location.href =
                        "Codex.html";

                    return;
                }


                window.location.href =
                    `Codex.html?catalog=${encodeURIComponent(
                        option.value
                    )}`;
            }
        );
    }


    async function appendCatalogs(
        select,
        catalogs,
        parentPath,
        depth,
        printPosts,
        hidePosts,
        separatorBefore
    ) {
        for (
            const [name, node]
            of Object.entries(
                catalogs
            )
        ) {
            /* Skip empty Catalog branches. */
            if (!catalogHasPosts(node)) {
                continue;
            }


            const path =
                parentPath
                    ? `${parentPath}/${name}`
                    : name;


            /*
             * A separator is represented by an OPTGROUP label,
             * not by a selectable OPTION. This keeps the native
             * SELECT behavior while giving separator_before the
             * same visual meaning in the dropdown.
             */
            let catalogOption =
                createOption(
                    path,
                    `${indent(depth)}✧ ${name}`,
                    "catalog",
                    path
                );

            if (separatorBefore.has(path)) {
                const separatorGroup =
                    document.createElement("optgroup");

                separatorGroup.label =
                    "────────────────";

                separatorGroup.appendChild(
                    catalogOption
                );

                select.appendChild(
                    separatorGroup
                );
            } else {
                select.appendChild(
                    catalogOption
                );
            }


            if (
                printPosts.has(path) &&
                !hidePosts.has(path) &&
                Array.isArray(
                    node?.posts
                )
            ) {
                const titles =
                    await loadPostTitles(
                        node.posts
                    );


                node.posts.forEach(
                    postId => {
                        select.appendChild(
                            createOption(
                                postId,
                                `${indent(depth + 1)}✦ ${
                                    titles.get(postId) ||
                                    humanizeId(postId)
                                }`,
                                "post",
                                postId
                            )
                        );
                    }
                );
            }


            if (
                node?.children &&
                typeof node.children ===
                    "object"
            ) {
                await appendCatalogs(
                    select,
                    node.children,
                    path,
                    depth + 1,
                    printPosts,
                    hidePosts,
                    separatorBefore
                );
            }
        }
    }


    function catalogHasPosts(node) {
        if (!node || typeof node !== "object") {
            return false;
        }


        if (
            Array.isArray(node.posts) &&
            node.posts.length > 0
        ) {
            return true;
        }


        if (
            node.children &&
            typeof node.children === "object"
        ) {
            return Object.values(node.children)
                .some(child => catalogHasPosts(child));
        }


        return false;
    }


    async function loadPostTitles(
        postIds
    ) {
        const titles =
            new Map();


        await Promise.all(
            postIds.map(
                async postId => {
                    try {
                        const response =
                            await fetch(
                                `Codex-Text/${encodeURIComponent(
                                    postId
                                )}.json`
                            );


                        if (!response.ok) {
                            return;
                        }


                        const data =
                            await response.json();


                        /*
                         * Only trust the title
                         * when the Post JSON
                         * confirms its own ID.
                         */
                        if (
                            data &&
                            data.id === postId &&
                            data.title
                        ) {
                            titles.set(
                                postId,
                                data.title
                            );
                        }

                    } catch {
                        /*
                         * Falls back to
                         * readable Post ID.
                         */
                    }
                }
            )
        );


        return titles;
    }


    function buildTagSelector(
        data
    ) {
        const select =
            tagRoot.querySelector(
                "select"
            );


        if (!select) {
            return;
        }


        const placeholder =
            select.querySelector(
                'option[value=""]'
            );


        select.textContent = "";


        if (placeholder) {
            select.appendChild(
                placeholder
            );

        } else {
            const option =
                createOption(
                    "",
                    "⛛ Select Tag",
                    "placeholder"
                );


            option.disabled =
                true;

            option.selected =
                true;

            option.hidden =
                true;


            select.appendChild(
                option
            );
        }


        let visibleGroupCount = 0;


        for (
            const [groupName, tags]
            of Object.entries(
                data?.groups || {}
            )
        ) {
            if (!Array.isArray(tags)) {
                continue;
            }


            /*
             * A Tag is visible only when W-Tag.json
             * actually maps it to at least one Post.
             */
            const visibleTags =
                tags.filter(tag =>
                    Array.isArray(
                        data?.tags?.[tag]?.posts
                    ) &&
                    data.tags[tag].posts.length > 0
                );


            if (visibleTags.length === 0) {
                continue;
            }


            const group =
                document.createElement(
                    "optgroup"
                );


            group.label =
                `✥ ${groupName}`;


            visibleTags.forEach(
                tag => {
                    group.appendChild(
                        createOption(
                            tag,
                            `#${tag}`,
                            "tag",
                            tag
                        )
                    );
                }
            );


            select.appendChild(
                group
            );

            visibleGroupCount += 1;
        }


        tagRoot.hidden =
            visibleGroupCount === 0;


        select.addEventListener(
            "change",
            () => {
                const option =
                    select.options[
                        select.selectedIndex
                    ];


                if (!option) {
                    return;
                }


                window.location.href =
                    `Codex.html?tag=${encodeURIComponent(
                        option.value
                    )}`;
            }
        );
    }


    function createOption(
        value,
        text,
        type,
        target = ""
    ) {
        const option =
            document.createElement(
                "option"
            );


        option.value =
            value;

        option.textContent =
            text;

        option.dataset.type =
            type;


        if (target) {
            option.dataset.target =
                target;
        }


        return option;
    }


    function indent(depth) {
        return "\u3000".repeat(
            depth
        );
    }


    function humanizeId(id) {
        return String(id || "")
            .replace(/^_/, "")
            .replace(/[-_]+/g, " ")
            .trim();
    }
})();